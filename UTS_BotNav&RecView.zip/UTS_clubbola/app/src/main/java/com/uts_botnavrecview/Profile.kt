package com.uts_botnavrecview

data class Profile(
    var imgProfile :Int,
    var nameProfile :String,
    var descProfile : String
)
